#!/bin/bash
set -euo pipefail

show_help(){ cat <<'H'
Uso: backup_full.sh <origen> <destino>
Genera <destino>/<nombre>_bkp_YYYYMMDD.tar.gz
Ejemplos:
    backup_full.sh /var/logs /backup_dir
    backup_full.sh /www_dir /backup_dir
H
}

[[ "${1:-}" == "-help" || "$#" -lt 2 ]] && { show_help; exit 0; }

SRC="$1"
DST="$2"
[[ -e "$SRC" ]] || { echo "Error: origen no existe: $SRC"; exit 2; }
[[ -d "$DST" ]] || { echo "Error: destino no existe o no es dir: $DST"; exit 3; }
mountpoint -q "$DST" || echo "Aviso: $DST no es un punto de montaje."

DATE=$(date +%Y%m%d)
BASE=$(basename "$SRC" | tr -c 'A-Za-z0-9_' '_')
OUT="$DST/${BASE}_bkp_${DATE}.tar.gz"

if [[ -d "$SRC" ]]; then
    tar -C / -czf "$OUT" "${SRC#/}"
elif [[ -f "$SRC" ]]; then
    tar -C "$(dirname "$SRC")" -czf "$OUT" "$(basename "$SRC")"
else
    echo "Error: tipo de origen no soportado"; exit 4
fi

echo "Backup generado: $OUT"
