# Trabajo Práctico Integrador – Computación Aplicada
Universidad de Palermo — 2025

- Integrantes:
  - Marco Antonio Braithwaite Paredes
  - Lucas Cristaldo
  - Celina Galloni
  - Matheo Maidana
